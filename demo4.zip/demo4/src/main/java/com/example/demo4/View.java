package com.example.demo4;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javax.net.ssl.SSLContext;
import java.io.File;

public class View extends VBox implements Subscriber {
    Model model;
    Button button1, button2, button3, button4;

    ImageView image;

    public void setModel( Model model ) {
        this.model = model;
    }

    public void setupEvents( Controller controller ) {
        button1.setOnMouseClicked( event -> {
            controller.handleButtonClicked( button1.getText() );
        } );
        button2.setOnMouseClicked( event -> {
            controller.handleButtonClicked( button2.getText() );
        } );
        button3.setOnMouseClicked( event -> {
            controller.handleButtonClicked( button3.getText() );
        } );
        button4.setOnMouseClicked( event -> {
            controller.handleButtonClicked( button4.getText() );
        } );
    }

    public View() {
        button1 = new Button();
        button2 = new Button();
        button3 = new Button();
        button4 = new Button();
        button1.setStyle( "-fx-color: YELLOW; -fx-font-color: BLUE; -fx-padding: 10, 10; -fx-font-size: 15; -fx-font-weight: bold" );
        button2.setStyle( "-fx-color: YELLOW; -fx-font-color: BLUE; -fx-padding: 10, 10; -fx-font-size: 15; -fx-font-weight: bold" );
        button3.setStyle( "-fx-color: YELLOW; -fx-font-color: BLUE; -fx-padding: 10, 10; -fx-font-size: 15; -fx-font-weight: bold" );
        button4.setStyle( "-fx-color: YELLOW; -fx-font-color: BLUE; -fx-padding: 10, 10; -fx-font-size: 15; -fx-font-weight: bold" );
        image = new ImageView();
        image.setFitWidth( 256 * 2 );
        image.setFitWidth( 192 * 2);

        HBox buttonBar = new HBox();
        buttonBar.setSpacing( 15 );
        buttonBar.setAlignment( Pos.CENTER );
        buttonBar.getChildren().addAll( button1, button2, button3, button4 );

        this.setAlignment( Pos.CENTER );
        this.setSpacing( 15 );
        this.getChildren().addAll( image, buttonBar );
    }

    public void receiveNotification() {
        String[] choices = model.getChoices();
        image.setImage( model.getFlagImage() );
        button1.setText( choices[0] );
        button2.setText( choices[1] );
        button3.setText( choices[2] );
        button4.setText( choices[3] );
    }

}
