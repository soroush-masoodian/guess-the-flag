package com.example.demo4;

import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class ScoreBoardView extends HBox implements Subscriber {
    Label correctLabel, wrongLabel, totalScoreLabel;
    Model model;

    public ScoreBoardView() {
        correctLabel = new Label( "Correct: 0" );
        wrongLabel = new Label( "Incorrect: 0" );
        totalScoreLabel = new Label( "Total score: 0" );

        correctLabel.setStyle( "-fx-font-color: BLUE; -fx-font-size: 15; -fx-font-weight: bold" );
        wrongLabel.setStyle( "-fx-font-color: BLUE; -fx-font-size: 15; -fx-font-weight: bold" );
        totalScoreLabel.setStyle( "-fx-font-color: BLUE; -fx-font-size: 15; -fx-font-weight: bold" );


        this.setStyle( "-fx-spacing: 10" );
        this.getChildren().addAll( correctLabel, wrongLabel, totalScoreLabel );
    }

    public void setModel( Model model ) {
        this.model = model;
    }

    public void updateView() {
        correctLabel.setText( "Correct: " + model.correctAnswers );
        wrongLabel.setText( "Wrong: " + model.wrongAnswers );
        totalScoreLabel.setText( "Total score: " + model.totalScore );
    }

    public void receiveNotification() {
        updateView();
    }
}
