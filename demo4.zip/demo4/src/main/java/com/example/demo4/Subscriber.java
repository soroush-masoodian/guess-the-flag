package com.example.demo4;

public interface Subscriber {
    void receiveNotification();
}
