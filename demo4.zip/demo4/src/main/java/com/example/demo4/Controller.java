package com.example.demo4;

public class Controller {
    PubSub publisher;
    Model model;

    public void setModel( Model model ) {
        this.model = model;
    }

    public void addPublisher( PubSub publisher ) {
        this.publisher = publisher;
    }

    public void handleButtonClicked( String choice ) {
        if ( model.getAnswer().equals( choice ) ) {
            model.addCorrectAnswers();
        }
        else {
            model.addWrongAnswers();
        }
        model.updateModel();
        publisher.notifySubs();
    }
}
