package com.example.demo4;

import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import javafx.scene.image.Image;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.google.gson.*;

public class Model {
    PubSub publisher;
    String[] choices;
    ArrayList<Country> countriesList;
    String answer;
    final int NUMBER_OF_CHOICES = 4;
    int correctAnswers, wrongAnswers, totalScore;


    public record Country( String flag, String country, String code ) {
    }

    public Model() {
        choices = new String[NUMBER_OF_CHOICES];
        countriesList = importFlagsMapData();
        correctAnswers = 0;
        wrongAnswers = 0;
        totalScore = 0;
        updateModel();
    }

    public ArrayList<Country> importFlagsMapData() {
        try {
            Gson gson = new Gson();

            String filePath = Model.class.getResource( "country-flag.json" ).getPath();
            filePath = filePath.substring( 1 );
            Type listType = new TypeToken<List<Country>>() {
            }.getType();

            return gson.fromJson( Files.readString( Path.of( filePath ) ), listType );
        } catch ( Exception e ) {
            System.out.println( e.getMessage() );
            return new ArrayList<>();
        }
    }

    public String getAnswer() {
        return answer;
    }

    public Image getFlagImage() {
        for ( Country c : countriesList ) {
            if ( c.country.equals( answer ) ) {
                return new Image( String.valueOf( Model.class.getResource( c.code + ".png" ).getPath() ).substring( 1 ) );
            }
        }
        return new Image( "" );
    }

    public String[] getChoices() {
        return choices;
    }

    public void addPublisher( PubSub publisher ) {
        this.publisher = publisher;
    }

    public void addCorrectAnswers() {
        correctAnswers += 1;
        totalScore = correctAnswers - wrongAnswers;
    }

    public void addWrongAnswers() {
        wrongAnswers += 1;
        totalScore = correctAnswers - wrongAnswers;
    }

    public void updateModel() {
        for ( int i = 0; i < NUMBER_OF_CHOICES; i++ ) {
            choices[i] = importFlagsMapData().get( (int) Math.floor( Math.random() * countriesList.size() ) ).country;
        }
        answer = choices[(int) Math.floor( Math.random() * NUMBER_OF_CHOICES )];
    }

}
