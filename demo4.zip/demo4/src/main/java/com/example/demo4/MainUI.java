package com.example.demo4;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;

public class MainUI extends BorderPane {
    double winSize;

    public MainUI( double windowSize ) {
        winSize = windowSize;

        Model model = new Model();
        Controller controller = new Controller();
        View view = new View();
        ScoreBoardView sbView = new ScoreBoardView();
        PubSub notifier = new PubSub();

        notifier.addSubscriber( view );
        notifier.addSubscriber( sbView );
        view.setModel( model );
        sbView.setModel( model );
        view.setupEvents( controller );

        controller.setModel( model );
        controller.addPublisher( notifier );

        model.addPublisher( notifier );

        this.setCenter( view );
        this.setBottom( sbView );

        notifier.notifySubs();
    }
}
