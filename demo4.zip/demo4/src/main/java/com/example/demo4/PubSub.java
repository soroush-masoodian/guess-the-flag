package com.example.demo4;

import java.util.ArrayList;

public class PubSub {
    ArrayList<Subscriber> subscribers;

    public PubSub() {
        subscribers = new ArrayList<>();
    }

    public void addSubscriber(Subscriber sub) {
        subscribers.add( sub );
    }

    public void notifySubs() {
        for ( Subscriber sub : subscribers ) {
            sub.receiveNotification();
        }
    }
}